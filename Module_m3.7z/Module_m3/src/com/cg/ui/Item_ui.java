package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.*;
import com.cg.helper.*;
import com.cg.validator.*;
import com.cg.exception.*;

import static java.lang.System.out;
public class Item_ui 
{
	public static void main(String[] args)
	{
		int choice;
		Scanner sc=new Scanner(System.in);
		 while(true)
		 {
			 out.println("Enter your choice");
			 out.println("1......Add Details");
			 out.println("2......Display Details");
			 out.println("3......Count Of Records");
			 out.println("4......Delete Record");
			 out.println("5......Exit");
			 choice=sc.nextInt();
			 switch(choice)
			 {
			 	case 1:System.out.println("Add Details");
			 	addDetails();
					 break;
			 	case 2:System.out.println("display details");
				 break;
			 	case 3:System.out.println("Count of records");
				 break;
			 	case 4:System.out.println("Delete Record");
				 break;
			    default:
			    	    System.out.println("Exit");
			    		
			  }
			break; 
		 }

	}
		
		 public static void addDetails()
		 {
			 Scanner sc=new Scanner(System.in);
			 
			 Validation v=new Validation();
			 collectionfile collect=new collectionfile();
			 
			 String id,name,price;
			 double txnID;
			 
			 System.out.println("enter item ID:");
			 id=sc.next();
			/* if(Validation.validateID(id))
			 {
				 {
				 collect.addID(Integer.parseInt(id));
				 }
				 
				 
				 System.out.println("enter Item name:");
				 name=sc.next();
				 if(Validation.validateName(name))
				 {
					 {
					 collect.addName(name);
					 }
					
					 
				 
					 System.out.println("enter item price:");
					 price=sc.next();
					 if(Validation.validatePrice(price))
					 {
						 {
						 collect.addPrice(Double.parseDouble(price));
						 }
						 
						 
						 txnID=Math.random();
						 collect.addTxnID(txnID);
					 }
			 
				 }
			 }
		 }*/
}
}
	
		 
		 
