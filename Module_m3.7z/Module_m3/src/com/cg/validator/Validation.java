package com.cg.validator;

import java.util.regex.Pattern;

public class Validation 
{
	public static boolean validateID(String item_id)throws Exception
	{
		String custPattern="[A-Za-z]{6,20}";
		if(Pattern.matches(custPattern, item_id))
			{
	
			  return true;
			}	
		else
		{
			throw new Exception("The item id is not valid");
		}
		
	}
	public static boolean validateName(String item_name)throws Exception
		{
			String custPattern="[A-Za-z]{6,20}";
			if(Pattern.matches(custPattern, item_name))
				{
		
				  return true;
				}	
			else
			{
				throw new Exception("The item name is not Valid");
			}
		}	
	public static boolean validatePrice(String price)throws Exception
	{
		String custPattern="[A-Za-z]{6,20}";
		if(Pattern.matches(custPattern, price))
			{
	
			  return true;
			}	
		else
		{
			throw new Exception("The item price is not Valid");
		}
		
	}
}
