package com.cg.helper;

public class collectionfile
{
	public void addID(int id)
	{
		
	}
	public void addName(String name)
	{
		
	}
	public void addPrice(double price)
	{
		
	}
	public void addTxnID(double txnID)
	{
		
	}
}
