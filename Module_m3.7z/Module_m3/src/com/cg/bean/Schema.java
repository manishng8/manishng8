package com.cg.bean;

public class Schema 
{
	int item_id;
	String item_name;
	double item_price;
	int transaction_id;
	
	public Schema(int item_id, String item_name, double item_price, int transaction_id)
	{
		this.item_id=item_id;
		this.item_name=item_name;
		this.item_price=item_price;
		this.transaction_id=transaction_id;
		
	}

	@Override
	public String toString() {
		return "Schema [item_id=" + item_id + ", item_price=" + item_price
				+ ", transaction_id=" + transaction_id + "]";
	}
}
